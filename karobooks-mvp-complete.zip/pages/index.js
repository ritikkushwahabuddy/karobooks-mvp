import { useState, useEffect } from "react";

export default function KaroBooks() {
  const [invoice, setInvoice] = useState({
    bizName: "आपका किराना",
    bizGSTIN: "",
    bizState: "09",
    custName: "",
    custGSTIN: "",
    custState: "09",
    items: [{ name: "", hsn: "", qty: 1, rate: 0, gstRate: 18 }],
    subTotal: 0, cgst: 0, sgst: 0, igst: 0, total: 0
  });

  const hsnData = [
    {name: "चावल Rice", hsn: "1006", gst: 5},
    {name: "दूध Milk", hsn: "0401", gst: 5},
    {name: "लैपटॉप Laptop", hsn: "8471", gst: 18},
    {name: "इस्पात Steel", hsn: "7208", gst: 18}
  ];

  const updateField = (field, value) => setInvoice(p => ({...p, [field]: value}));

  const updateItem = (idx, key, value) => {
    const newItems = [...invoice.items];
    newItems[idx][key] = value;
    setInvoice({...invoice, items: newItems});
    calculateTotals();
  };

  const addItem = () => setInvoice(p => ({...p, items: [...p.items, {name:"", hsn:"", qty:1, rate:0, gstRate:18}]}));

  const removeItem = (idx) => {
    const newItems = invoice.items.filter((_,i)=>i!==idx);
    setInvoice({...invoice, items: newItems});
  };

  const calculateTotals = () => {
    let sub = 0;
    invoice.items.forEach(item => sub += item.qty * item.rate);
    const sameState = invoice.bizState === invoice.custState;
    const gstRate = invoice.items[0]?.gstRate || 18;
    const gstAmt = sameState ? sub * gstRate / 200 : sub * gstRate / 100;
    setInvoice({
      ...invoice,
      subTotal: sub,
      cgst: sameState ? gstAmt : 0,
      sgst: sameState ? gstAmt : 0,
      igst: sameState ? 0 : gstAmt,
      total: sub + (sameState ? gstAmt*2 : gstAmt)
    });
  };

  const generatePDF = async () => {
    const { jsPDF } = await import('jspdf');
    const doc = new jsPDF();
    doc.setFontSize(20);
    doc.text("🧾 GST Invoice", 20, 30);
    doc.setFontSize(12);
    doc.text(`From: ${invoice.bizName}`, 20, 50);
    doc.text(`GSTIN: ${invoice.bizGSTIN}`, 20, 60);
    doc.text(`To: ${invoice.custName}`, 20, 80);
    doc.text(`GSTIN: ${invoice.custGSTIN}`, 20, 90);
    let y = 110;
    invoice.items.forEach(item => {
      doc.text(`${item.name} (${item.hsn}) Q:${item.qty} @₹${item.rate}`, 20, y);
      y += 10;
    });
    y += 10;
    doc.text(`Subtotal: ₹${invoice.subTotal.toFixed(2)}`, 20, y);
    doc.text(`CGST: ₹${invoice.cgst.toFixed(2)}`, 20, y+10);
    doc.text(`SGST: ₹${invoice.sgst.toFixed(2)}`, 20, y+20);
    doc.text(`IGST: ₹${invoice.igst.toFixed(2)}`, 20, y+30);
    doc.text(`TOTAL: ₹${invoice.total.toFixed(2)}`, 20, y+50, {style: 'bold'});
    doc.save("karobooks-invoice.pdf");
  };

  const paymentLink = () => {
    const link = `https://rzp.io/i/${Math.random().toString(36).substr(2, 9)}`;
    window.open(link, "_blank");
    alert("Payment link opened! Razorpay Sandbox");
  };

  useEffect(() => calculateTotals(), []);

  return (
    <div style={{maxWidth:900,margin:"0 auto",padding:30,fontFamily:"Arial",lineHeight:1.6}}>
      <h1 style={{textAlign:"center",color:"#10b981"}}>🚀 KaroBooks GST Invoice</h1>
      <p style={{textAlign:"center",color:"#6b7280"}}>30 सेकंड में GST बिल | Free Beta</p>

      <div style={{display:"grid",gap:10,marginBottom:20}}>
        <input style={{padding:10}} placeholder="व्यवसाय नाम" value={invoice.bizName} onChange={e=>updateField("bizName",e.target.value)} />
        <input style={{padding:10}} placeholder="GSTIN (09xxxxxxxxx)" value={invoice.bizGSTIN} onChange={e=>updateField("bizGSTIN",e.target.value)} />
        <select style={{padding:10}} value={invoice.bizState} onChange={e=>updateField("bizState",e.target.value)}>
          <option value="09">UP 09</option><option value="29">KA 29</option><option value="22">UP 22</option>
        </select>
        <input style={{padding:10}} placeholder="ग्राहक नाम" value={invoice.custName} onChange={e=>updateField("custName",e.target.value)} />
        <input style={{padding:10}} placeholder="ग्राहक GSTIN" value={invoice.custGSTIN} onChange={e=>updateField("custGSTIN",e.target.value)} />
        <select style={{padding:10}} value={invoice.custState} onChange={e=>updateField("custState",e.target.value)}>
          <option value="09">UP 09</option><option value="29">KA 29</option><option value="22">UP 22</option>
        </select>
      </div>

      <h3>वस्तुएं Items ➕</h3>
      {invoice.items.map((item,idx) => (
        <div key={idx} style={{border:"1px solid #d1d5db",padding:15,marginBottom:10,display:"grid",gap:8,gridTemplateColumns:"3fr 1fr 1fr 1fr auto"}}>
          <input list={`hsnlist${idx}`} placeholder="Item/HSN (चावल type करो)" onChange={e=>{
            const val = e.target.value;
            const match = hsnData.find(h=>val.includes(h.hsn) || val.includes(h.name.split(" ")[0]));
            if(match){
              updateItem(idx,"hsn",match.hsn);
              updateItem(idx,"name",match.name);
              updateItem(idx,"gstRate",match.gst);
            } else updateItem(idx,"name",val);
          }} />
          <datalist id={`hsnlist${idx}`}>
            {hsnData.map(h=><option value={h.name} key={h.hsn} />)}
          </datalist>
          <input type="number" placeholder="Qty" value={item.qty} onChange={e=>updateItem(idx,"qty",parseFloat(e.target.value)||1)} min="1" />
          <input type="number" placeholder="Rate ₹" value={item.rate} onChange={e=>updateItem(idx,"rate",parseFloat(e.target.value)||0)} min="0" />
          <select value={item.gstRate} onChange={e=>updateItem(idx,"gstRate",parseInt(e.target.value))}>
            <option>0</option><option>5</option><option>12</option><option>18</option>
          </select>
          <button onClick={()=>removeItem(idx)} style={{background:"#ef4444",color:"white",border:"none",padding:5}}>X</button>
        </div>
      ))}
      <button onClick={addItem} style={{background:"#3b82f6",color:"white",padding:"12px 24px",border:"none",borderRadius:6}}>➕ नई वस्तु</button>

      <div style={{marginTop:25,padding:20,background:"#f3f4f6",borderRadius:8}}>
        <h3>सारांश Summary</h3>
        <p>Subtotal: <strong>₹{invoice.subTotal.toFixed(2)}</strong></p>
        <p>CGST (9%): <strong>₹{invoice.cgst.toFixed(2)}</strong></p>
        <p>SGST (9%): <strong>₹{invoice.sgst.toFixed(2)}</strong></p>
        <p>IGST (18%): <strong>₹{invoice.igst.toFixed(2)}</strong></p>
        <h2 style={{color:"#10b981"}}>कुल Total: ₹{invoice.total.toFixed(2)}</h2>
      </div>

      <div style={{textAlign:"center",marginTop:30,gap:15,display:"flex",flexWrap:"wrap",justifyContent:"center"}}>
        <button onClick={calculateTotals} style={{padding:"12px 24px",background:"#6b7280",color:"white",border:"none",borderRadius:6}}>गणना Calculate</button>
        <button onClick={generatePDF} style={{padding:"12px 24px",background:"#10b981",color:"white",border:"none",borderRadius:6}}>📄 PDF डाउनलोड</button>
        <button onClick={paymentLink} style={{padding:"12px 24px",background:"#3b82f6",color:"white",border:"none",borderRadius:6}}>💳 Payment Link</button>
      </div>

      <div style={{textAlign:"center",marginTop:40,fontSize:14,color:"#6b7280"}}>
        Beta v1.0 | Made for UP Kiranas | Share: karobooks.in
      </div>
    </div>
  );
}