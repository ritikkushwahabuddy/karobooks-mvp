# KaroBooks GST MVP

## Deploy
1. GitHub → New Repo → Upload ZIP
2. Vercel.com → Import Repo → Deploy

Live in 2 mins!

## Test
- Add "चावल" → HSN auto
- Calc GST
- PDF + Payment link

Month 1: 50 users ₹10K MRR